# -*- coding: utf-8 -*-
"""
Created on Sat Oct  6 16:59:03 2018

@author: yangkui
"""
import mnist_loader
import network

if __name__ == '__main__':
    training_data, validation_data, test_data = mnist_loader.load_data_wrapper()
    net = network.Network([784, 30, 10]) #28*28
    net.gradient_descent(training_data, 30, 10, 3.0, test_data=test_data)